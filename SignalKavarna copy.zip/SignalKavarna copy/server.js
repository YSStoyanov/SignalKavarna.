const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const signalsRoutes = require('./routes/signals');
const authRoutes = require('./routes/auth');

// Секретен ключ за JWT
const SECRET_KEY = 'supersecretkey12345';

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

// PostgreSQL конфигурация
const pool = new Pool({
    user: 'postgres',
    host: 'localhost',
    database: 'city_signals',
    password: '17212430',
    port: 5432,
});

// JWT middleware
function authenticateToken(req, res, next) {
    const token = req.headers['authorization'];
    if (!token) return res.status(401).json({ error: 'Липсва токен' });

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) return res.status(403).json({ error: 'Невалиден токен' });
        req.user = user;
        next();
    });
}

// Роутове
app.use('/api/signals', authenticateToken, signalsRoutes);
app.use('/api/auth', authRoutes);

// Стартиране на сървъра
app.listen(PORT, () => {
    console.log(`Сървърът работи на http://localhost:${PORT}`);
});